/**
 * Created by horacio on 4/8/16.
 */


define([], function () {
    var GameInput = Class.extend({
        init: function (game) {
            this.game = game;
            this.caminarKeys = [Enums.Keys.LEFT, Enums.Keys.KEYPAD_4, Enums.Keys.RIGHT, Enums.Keys.KEYPAD_6, Enums.Keys.UP, Enums.Keys.KEYPAD_8, Enums.Keys.DOWN, Enums.Keys.KEYPAD_2];
        },

        isCaminarKey: function (key) {
            return this.caminarKeys.indexOf(key) > -1;
        },

        click: function () {
            if ((!this.game.started) || (this.game.isPaused))
                return;
            this.game.click();
        },

        doubleClick: function () {

            if ((!this.game.started) || (this.game.isPaused))
                return;
            this.game.doubleClick();
        },

        keyUp: function (key) {
            var game = this.game;

            if (!game.started)
                return;
            switch (key) {
                case Enums.Keys.LEFT:
                case Enums.Keys.KEYPAD_4:
                    game.terminarDeCaminar(Enums.Heading.oeste);
                    break;
                case Enums.Keys.RIGHT:
                case Enums.Keys.KEYPAD_6:
                    game.terminarDeCaminar(Enums.Heading.este);
                    break;
                case Enums.Keys.UP:
                case Enums.Keys.KEYPAD_8:
                    game.terminarDeCaminar(Enums.Heading.norte);
                    break;
                case Enums.Keys.DOWN:
                case Enums.Keys.KEYPAD_2:
                    game.terminarDeCaminar(Enums.Heading.sur);
                    break;
                default:
                    break;

            }
        },

        keyDown: function (key) {
            var game = this.game;

            if (!game.started)
                return;

            switch (key) {
                case Enums.Keys.LEFT:
                case Enums.Keys.KEYPAD_4:
                    game.caminar(Enums.Heading.oeste);
                    break;
                case Enums.Keys.RIGHT:
                case Enums.Keys.KEYPAD_6:
                    game.caminar(Enums.Heading.este);
                    break;
                case Enums.Keys.UP:
                case Enums.Keys.KEYPAD_8:
                    game.caminar(Enums.Heading.norte);
                    break;
                case Enums.Keys.DOWN:
                case Enums.Keys.KEYPAD_2:
                    game.caminar(Enums.Heading.sur);
                    break;
                case Enums.Keys.A:
                    game.agarrar();
                    break;
                case Enums.Keys.O:
                    game.ocultarse();
                    break;
                case Enums.Keys.L:
                    game.requestPosUpdate();
                    break;
                case Enums.Keys.E:
                    game.equiparSelectedItem();
                    break;
                case Enums.Keys.U:
                    game.usarConU();
                    break;
                case Enums.Keys.CONTROL:
                    game.atacar();
                    break;
                case Enums.Keys.T:
                    game.tratarDeTirarItem();
                    break;
                default:
                    continuar = true;
                    break;
            }

        },
    });

    return GameInput;
});