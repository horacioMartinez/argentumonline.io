/**
 * Created by horacio on 4/6/16.
 */


define(['input/gameinput'], function (GameInput/*SACAME*/) {
    var GameInputHandler = Class.extend({

        init: function (game) {
            this.game = game; // sacame
            this.gameInput = new GameInput(game); // no se deberia creaer aca!!

            this._prevKeyDown = {};
        },

        showChat: function () {
            $('#chatbox').addClass('active');
            $('#chatinput').focus();
        },

        hideChat: function () {
            $('#chatbox').removeClass('active');
            $('#chatinput').blur();
        },

        inGameMouseCoordinates: function (game, event) {

            var gamePos = $('#gamecanvas').offset(),
                width = game.renderer.pixiRenderer.width,
                height = game.renderer.pixiRenderer.height,
                mouse = game.mouse;

            mouse.x = event.pageX - gamePos.left;
            mouse.y = event.pageY - gamePos.top;

            var posEnGameCanvas = true;
            if (mouse.x <= 0) {
                mouse.x = 0;
                posEnGameCanvas = false;
            } else if (mouse.x >= width) {
                mouse.x = width - 1;
                posEnGameCanvas = false;
            }

            if (mouse.y <= 0) {
                mouse.y = 0;
                posEnGameCanvas = false;
            } else if (mouse.y >= height) {
                mouse.y = height - 1;
                posEnGameCanvas = false;
            }
            return posEnGameCanvas;
        },

        initGameInputListeners: function () {
            var self = this;
            var game = this.game;
            var gameInput = this.gameInput;

            $('#chatbox').attr('value', '');

            $('#gamecanvas').click(function (event) {
                // TODO: si haces click afuera del menu pop up que lo cierre?

                if (self.inGameMouseCoordinates(game, event)) {
                    gameInput.click();
                }
            });

            $('#gamecanvas').dblclick(function (event) {
                // TODO: si haces click afuera del menu pop up que lo cierre?
                if (self.inGameMouseCoordinates(game, event)) {
                    gameInput.doubleClick();
                }
            });

            $(document).keyup(function (e) {
                var key = e.which;
                self._upKey(e);
                gameInput.keyUp(key);
            });

            $(document).keydown(function (e) {
                if (!game.started)
                    return;

                var key = e.which;

                if (!self._isKeyDown(e))
                    gameInput.keyDown(key);

                if (gameInput.isCaminarKey(key)) {
                    self._downKey(e);

                    if (!game.gameUI.hayPopUpActivo()) { // si hay un popup abierto dejar que siga la tecla al pop up, sino no
                        return false;
                    }
                    return;
                }

                if (game.isPaused || (game.gameUI.hayPopUpActivo()))
                    return;
                // lo de abajo se ejecuta solo si no hay un pop up abierto

                $chatb = $('#chatbox');

                if (key === Enums.Keys.ENTER) {
                    if ($chatb.hasClass('active')) {
                        self.hideChat();
                    } else {
                        self.showChat();
                    }
                }

                if (!$chatb.hasClass('active') /* && !this.game.uiRenderer.popUpActivo*/) {
                    if (self._isKeyDown(e))
                        return;
                    self._downKey(e);
                    e.preventDefault();
                    gameInput.keyDown(key);
                }
            });

            $('#chatinput').keydown(function (e) {

                var key = e.which;

                if (key === 13) {
                    $chat = $('#chatinput');
                    if ($chat.attr('value') !== '') {
                        if (game.player) {
                            game.enviarChat($chat.val());
                        }
                        $chat.val('');
                        self.hideChat();
                        $('#gamecanvas').focus();
                        return false;
                    } else {
                        self.hideChat();
                        return false;
                    }
                }

                if (key === 27) {
                    self.hideChat();
                    return false;
                }
            });

            $(document).bind("keydown", function (e) {
                var key = e.which;

                if (key === 13) { // Enter
                    $chat = $('#chatinput');
                    if (game.started) {
                        $chat.focus();
                        return false;
                    }
                }
            });
        },

        _downKey: function (e) {
            var wh = e.which;
            var kC = e.keyCode;
            if (this._prevKeyDown[wh] == null) {
                this._prevKeyDown[wh] = {};
            }
            this._prevKeyDown[wh][kC] = true;
        },

        _upKey: function (event) {
            var wh = event.which;
            var kC = event.keyCode;

            if (this._prevKeyDown[wh] != null) {
                this._prevKeyDown[wh][kC] = null;
            }
        },

        _isKeyDown: function (event) {
            var wh = event.which;
            var kC = event.keyCode;

            var result = false;

            if (this._prevKeyDown[wh] != null) {
                if (this._prevKeyDown[wh][kC] == true) {
                    result = true;
                }
            }
            return result;
        }

    });

    return GameInputHandler;
});

/*
 // DEBUGGGGGGGGGGGGGGGGG:
 $(window).bind('mousewheel DOMMouseScroll', function(event){
 var escala;
 if (event.originalEvent.wheelDelta > 0 || event.originalEvent.detail < 0) {
 //scroll up
 escala = 1.1;
 }
 else {
 // scroll down
 escala = 0.9;
 }
 game.renderer.stage.scale.x *= escala;
 game.renderer.stage.scale.y *= escala;
 game.renderer.stage.x = ((game.renderer.stage.width * (1-game.renderer.stage.scale.x))/2);
 game.renderer.stage.y = ((game.renderer.stage.height * (1-game.renderer.stage.scale.y))/2);
 });*/